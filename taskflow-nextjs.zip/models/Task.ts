
import mongoose, { Schema, models } from "mongoose";

const TaskSchema = new Schema(
  {
    title: { type: String, required: true },
    description: { type: String },
    dueDate: { type: Date },
    priority: { type: String, enum: ["Low", "Medium", "High"], default: "Medium" },
    status: { type: String, enum: ["Todo", "In-Progress", "Done"], default: "Todo" }
  },
  { timestamps: true }
);

export const Task = models.Task || mongoose.model("Task", TaskSchema);
