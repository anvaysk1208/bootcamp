
# TaskFlow – Next.js + TypeScript + Tailwind + MongoDB

A minimalist task management web app. Uses Next.js (pages router), TypeScript, Tailwind CSS, Context API, MongoDB (via Mongoose) and is deploy-ready on Vercel.

## Quick Start (Local)

1. Install dependencies:
   ```bash
   npm install
   ```
2. Create `.env.local` in the project root:
   ```bash
   MONGODB_URI=your_mongodb_connection_string
   ```
3. Run dev server:
   ```bash
   npm run dev
   ```
4. Visit `http://localhost:3000`

## Deploy on Vercel (recommended)

1. Push this folder to a GitHub repo.
2. Import the repo in Vercel.
3. Add environment variable in Vercel Project Settings → **MONGODB_URI** with your connection string.
4. Click **Deploy**.
5. Your live link will be `https://<project-name>.vercel.app` (paste this into forms).

## Tech Stack Used
- Next.js 14, TypeScript
- Tailwind CSS
- Context API (state management)
- MongoDB + Mongoose
- Deployed on Vercel

## API
- `GET /api/tasks` – list tasks
- `POST /api/tasks` – create task  (JSON body)
- `PUT /api/tasks/:id` – update task
- `DELETE /api/tasks/:id` – delete task
