
import React, { createContext, useContext, useEffect, useState } from "react";

export type Task = {
  _id?: string;
  title: string;
  description?: string;
  dueDate?: string;
  priority: "Low" | "Medium" | "High";
  status: "Todo" | "In-Progress" | "Done";
};

type Ctx = {
  tasks: Task[];
  loading: boolean;
  refresh: () => Promise<void>;
  createTask: (t: Omit<Task, "_id">) => Promise<void>;
  updateTask: (id: string, t: Partial<Task>) => Promise<void>;
  deleteTask: (id: string) => Promise<void>;
};

const TaskContext = createContext<Ctx | null>(null);

export const TaskProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [tasks, setTasks] = useState<Task[]>([]);
  const [loading, setLoading] = useState(true);

  const refresh = async () => {
    setLoading(true);
    const res = await fetch("/api/tasks");
    const data = await res.json();
    setTasks(data.tasks || []);
    setLoading(false);
  };

  const createTask = async (t: Omit<Task, "_id">) => {
    await fetch("/api/tasks", { method: "POST", headers: {"Content-Type": "application/json"}, body: JSON.stringify(t) });
    await refresh();
  };

  const updateTask = async (id: string, t: Partial<Task>) => {
    await fetch(`/api/tasks/${id}`, { method: "PUT", headers: {"Content-Type": "application/json"}, body: JSON.stringify(t) });
    await refresh();
  };

  const deleteTask = async (id: string) => {
    await fetch(`/api/tasks/${id}`, { method: "DELETE" });
    await refresh();
  };

  useEffect(() => { refresh(); }, []);

  return (
    <TaskContext.Provider value={{ tasks, loading, refresh, createTask, updateTask, deleteTask }}>
      {children}
    </TaskContext.Provider>
  );
};

export const useTasks = () => {
  const ctx = useContext(TaskContext);
  if (!ctx) throw new Error("useTasks must be used within TaskProvider");
  return ctx;
};
