
import Head from "next/head";
import { useState } from "react";
import { useTasks, Task } from "@/context/TaskContext";

export default function Home() {
  const { tasks, loading, createTask, updateTask, deleteTask } = useTasks();

  const [form, setForm] = useState<Omit<Task, "_id">>({
    title: "",
    description: "",
    dueDate: "",
    priority: "Medium",
    status: "Todo"
  });

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.title.trim()) return;
    await createTask(form);
    setForm({ title: "", description: "", dueDate: "", priority: "Medium", status: "Todo" });
  };

  return (
    <>
      <Head>
        <title>TaskFlow</title>
      </Head>
      <main className="min-h-screen bg-gray-50">
        <div className="max-w-5xl mx-auto p-6">
          <h1 className="text-3xl font-bold mb-6">TaskFlow</h1>

          <form onSubmit={submit} className="grid gap-3 bg-white p-4 rounded-2xl shadow">
            <input
              className="border rounded p-2"
              placeholder="Task title"
              value={form.title}
              onChange={(e) => setForm({ ...form, title: e.target.value })}
            />
            <textarea
              className="border rounded p-2"
              placeholder="Description"
              value={form.description}
              onChange={(e) => setForm({ ...form, description: e.target.value })}
            />
            <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
              <input
                type="date"
                className="border rounded p-2"
                value={form.dueDate}
                onChange={(e) => setForm({ ...form, dueDate: e.target.value })}
              />
              <select
                className="border rounded p-2"
                value={form.priority}
                onChange={(e) => setForm({ ...form, priority: e.target.value as any })}
              >
                <option>Low</option>
                <option>Medium</option>
                <option>High</option>
              </select>
              <select
                className="border rounded p-2"
                value={form.status}
                onChange={(e) => setForm({ ...form, status: e.target.value as any })}
              >
                <option>Todo</option>
                <option>In-Progress</option>
                <option>Done</option>
              </select>
            </div>
            <button className="bg-black text-white rounded-xl py-2">Add Task</button>
          </form>

          <div className="mt-8 grid gap-4">
            {loading ? (
              <p>Loading...</p>
            ) : tasks.length === 0 ? (
              <p className="text-gray-500">No tasks yet. Add your first task!</p>
            ) : (
              tasks.map((t) => (
                <div key={t._id} className="bg-white rounded-2xl shadow p-4 flex justify-between items-start">
                  <div>
                    <h3 className="font-semibold">{t.title}</h3>
                    {t.description && <p className="text-sm text-gray-600">{t.description}</p>}
                    <div className="text-xs text-gray-500 mt-1">
                      <span>Priority: {t.priority}</span>
                      {" · "}
                      <span>Status: {t.status}</span>
                      {t.dueDate && <>{" · "}Due: {new Date(t.dueDate).toLocaleDateString()}</>}
                    </div>
                  </div>
                  <div className="flex gap-2">
                    <select
                      className="border rounded p-1 text-sm"
                      value={t.status}
                      onChange={(e) => updateTask(t._id as string, { status: e.target.value as any })}
                    >
                      <option>Todo</option>
                      <option>In-Progress</option>
                      <option>Done</option>
                    </select>
                    <button
                      onClick={() => deleteTask(t._id as string)}
                      className="text-sm border rounded px-2 py-1"
                    >
                      Delete
                    </button>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>
      </main>
    </>
  );
}
