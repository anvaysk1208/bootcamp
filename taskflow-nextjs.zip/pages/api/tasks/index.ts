
import type { NextApiRequest, NextApiResponse } from "next";
import { dbConnect } from "@/lib/mongodb";
import { Task } from "@/models/Task";

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  await dbConnect();
  if (req.method === "GET") {
    const tasks = await Task.find().sort({ createdAt: -1 });
    return res.status(200).json({ tasks });
  }
  if (req.method === "POST") {
    try {
      const task = await Task.create(req.body);
      return res.status(201).json({ task });
    } catch (e: any) {
      return res.status(400).json({ error: e.message });
    }
  }
  return res.status(405).json({ error: "Method not allowed" });
}
